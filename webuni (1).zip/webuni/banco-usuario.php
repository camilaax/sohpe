<?php
function buscaUsuario($conexao, $login, $senha, $tipo){
	$senhaMd5 = md5($senha);
	$login = mysqli_real_escape_string($conexao, $email);
	$query = "select * from usuarios where email='{$login}' and senha='{$senhaMd5}';
	$resultado = mysqli_query($conexao, $query);
	$usuario = mysqli_fetch_assoc($resultado);
	return $usuario;
}
