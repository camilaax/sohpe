<?php


	function listaFormacoes($conexao) {
		$formacoes = array();
		$resultado = mysqli_query($conexao, "select * from formacoes");
		while($formacao = mysqli_fetch_assoc($resultado)) {
			array_push($formacoes, $formacao);
		}
		return $formacoes;
	}
	/*function insereProfessor($conexao, $nome, $formacao, $email){
		$nome = addslashes($nome);
		$formacao = addslashes($formacao);
		$query="insert into professores(nome, formacao, email) values('{$nome}','{$formacao}','{$email}')";
		$resultadoDaInsercao= mysqli_query($conexao, $query);
		return $resultadoDaInsercao;
	}
	function removeProfessor($conexao,$id){
		$query = "delete from professores where id={$id}";
		return mysqli_query($conexao,$query);
	}
	function buscaProfessor($conexao, $id){
		$query = "select * from professores where id={$id}";
		$resultado = mysqli_query($conexao, $query);
		return mysqli_fetch_assoc($resultado);
	}
	function alteraProfessor($conexao, $id, $nome, $formacao, $email, $disciplina_id) {
		$query = "update professores set nome = '{$nome}', formacao= {$formacao}, email = '{$email}', 
        iddisciplina = {$disciplina_id} where id = '{$id}'";
		return mysqli_query($conexao, $query);
	}*/
?>