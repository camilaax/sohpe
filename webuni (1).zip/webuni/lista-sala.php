
<?php 
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-sala.php");
$salas = listaSalas($conexao);
?>
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Salas</span>
				<?php 
					  if(array_key_exists("removido", $_GET) && $_GET['removido']=='true') { 
					?>
					  
					 <p class="alert-success">Sala apagada com sucesso.</p>

					<?php
					  }
 ?>
			</div>
		</div>
	</div>

<!-- Page info -->



<!-- Page info end -->
<table class="table table-striped table-bordered">
	<tr>
		<th><h4>Número</h4></th>
		<th><h4>Bloco</h4></th>
		<th><h4>Tipo</h4></th>
		<th><h4>Alterar</h4></th>
		<th><h4>Remover</h4></th>
		
	
	<?php
	
		foreach($salas as $sala){
			?>
			<tr>
				<td><?=$sala['numsala']?></td>
				<td><?=$sala['bloco']?></td>
				<td><?=$sala['tipo']?></td>
				<td>
					<form action="sala-altera-formulario.php?id=<?=$sala['id']?>" method="post">
						<input type="hidden" name="id" value="<?=$sala['id']?>"/>
							<button class="btn btn-primary">Alterar</button>
					</form>
				</td>
				<td>
					<form action="remove-sala.php?id=<?=$sala['id']?>" method="post">
						<input type="hidden" name="id" value="<?=$sala['id']?>"/>
							<button class="btn btn-danger">Remover</button>
					</form>
				</td>
			</tr>
		<?php }?>
</table>
<?php include("rodape.php");?>