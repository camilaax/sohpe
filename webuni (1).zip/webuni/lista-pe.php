<?php require_once("cabecalho.php");?>
<?php require_once("conecta.php")?>
<?php require_once("banco-pe.php");?>
<?php
	$permanencias = listaPermanencias($conexao);
?>
<?php
	if(array_key_exists("removido",$_GET)&& ($_GET['removido']=='true')){
?>
	<p class="alert-success">P.E. apagado com sucesso.</p>
<?php } ?>
<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/1.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Permanencias</span>
			</div>
		</div>
	</div>
<!-- Page info end -->
<h1>Lista de P.E</h1>
<table class="table table-striped table-bordered">
	<tr>
		<th><h4>Professor</h4></th>
		<th><h4>Sala</h4></th>
		<th><h4>Hora Inicio</h4></th>
		<th><h4>Hora Termino</h4></th>
		<th><h4>Semestre</h4></th>
		<th><h4>Dia da Semana</h4></th>
		<th><h4>Alterar</h4></th>
		<th><h4>Remover</h4></th>
	<?php
	foreach($permanencias as $permanencia){
		?>
		<tr>
			<td><?=$permanencia['idprofessor']?></td>
			<td><?=$permanencia['idsala']?></td>
			<td><?=$permanencia['horainico']?></td>
			<td><?=$permanencia['horatermino']?></td>
			<td><?=$permanencia['semestre']?></td>
			<td><?=$permanencia['diasemana']?></td>
			<td>
				<form action="pe-altera-formulario.php?id=<?=$permanencia['id']?>" method="post">
					<input type="hidden" name="id" value="<?=$permanencia['id']?>"/>
						<button class="btn btn-primary">Alterar</button>
				</form>
			</td>
			<td>
				<form action="remove-pe.php?id=<?=$permanencia['id']?>" method="post">
					<input type="hidden" name="id" value="<?=$permanencia['id']?>"/>
						<button class="btn btn-danger">Remover</button>
				</form>
			</td>
		</tr>
	<?php }?>
</table>
<?php include("rodape.php");?>