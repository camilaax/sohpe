<?php
include("cabecalho.php");
include("logica-usuario.php"); ?>


	<!-- Hero section -->
	<section class="hero-section set-bg" data-setbg="img/bg.jpg">
		<div class="container">
		<br><br><br><br><br><br><br><br><br><br><br><br><br>
			<div class="row">
				<div class="col-lg-10 offset-lg-1">
					<form class="intro-newslatter">
						<?php if(isset($_SESSION["success"])) { ?>
							 <p class="alert-success"> <?=$_SESSION["success"]?></p>
						<?php 
						unset($_SESSION["success"]);
					} ?>
				<?php if(isset($_SESSION["danger"])){ ?>
					<br><br><br><br>
					<p class="alert-danger"> <?=$_SESSION["danger"]?></p>
					<?php 
					unset($_SESSION["danger"]);
				} ?>
				<?php if(usuarioEstaLogado()){ ?>
							<p class="text-success">Você está logado como <?= usuarioLogado() ?>. 
							,<a href="logout.php">Deslogar</a></p>
					<?php } else { ?>
						
							<form class="intro-newslatter">
								<h3 class="h3 text-white mb-4">Login</h3>
								<div class="form-group">
									<input type="text" class="last-s" placeholder="Email">
								</div>
								<div class="form-group">
									<input type="password" class="form-control"  placeholder="Senha">
								</div>
								<div class="form-group">
									<input type="submit" class="btn btn-primary btn-pill" value="Entrar">
								</div>
							</form>
					
					<?php }  ?>
					</form>
				</div>
			</div>
		</div>
	</section>

<?php
include("rodape.php");
?>