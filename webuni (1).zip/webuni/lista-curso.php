<br>
<br>
<?php require_once("cabecalho.php");?>
<?php require_once("conecta.php")?>
<?php require_once("banco-curso.php");?>
<?php
	$cursos = listaCursos($conexao);
?>
<?php
	if(array_key_exists("removido",$_GET)&& ($_GET['removido']=='true')){
?>
	<p class="alert-success">Curso apagado com sucesso.</p>
<?php } ?>
<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/1.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="indexadm.php">Home</a>
				<span>Cursos</span>
			</div>
		</div>
	</div>
<!-- Page info end -->
<h1>Lista de cursos</h1>
<table class="table table-striped table-bordered">
	<tr>
		<th><h4>Nome</h4></th>
		<th><h4>Alterar</h4></th>
		<th><h4>Remover</h4></th>
	<?php
	foreach($cursos as $curso){
		?>
		<tr>
			<td><?=$curso['nome']?></td>
		
			<td>
				<form action="curso-altera-formulario.php?id=<?=$curso['id']?>" method="post">
					<input type="hidden" name="id" value="<?=$curso['id']?>"/>
						<button class="btn btn-primary">Alterar</button>
				</form>
			</td>
			<td>
				<form action="remove-curso.php?id=<?=$curso['id']?>" method="post">
					<input type="hidden" name="id" value="<?=$curso['id']?>"/>
						<button class="btn btn-danger">Remover</button>
				</form>
			</td>
		</tr>
	<?php }?>
</table>
<?php include("rodape.php");?>