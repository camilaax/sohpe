<?php 
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-pe.php");
$permanencias = listaPermanencias($conexao)
?>
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Permanências</span>
				<?php 
					  if(array_key_exists("removido", $_GET) && $_GET['removido']=='true') { 
					?>
					  
					 <p class="alert-success">Permanência apagada com sucesso.</p>

					<?php
					  }
 ?>
			</div>
		</div>
	</div>

<!-- Page info -->


<!-- Page info end -->
<table class="table table-striped table-bordered">
	<tr>
		<th><h4>Hora Início</h4></th>
		<th><h4>Hora Término</h4></th>
		<th><h4>Semestre</h4></th>
		<th><h4>Dia da semana</h4></th>
		<th><h4>Sala</h4></th>
		<th><h4>Professor</h4></th>
		<th><h4>Disciplina</h4></th>
		
		
	
	<?php
	
		foreach($permanencias as $permanencia){
			?>
			<tr>
				<td><?=$permanencia['horainicio']?></td>
				<td><?=$permanencia['horatermino']?></td>
				<td><?=$permanencia['semestre']?></td>
				<td><?=$permanencia['diasemana']?></td>
				<td><?=$permanencia['sala_bloco']?><?=$permanencia['sala_numsala']?></td>
				<td><?=$permanencia['professor_nome']?></td>
				<td>
					<form action="professor-disciplina-lista.php" method="post">
						<input type="hidden" name="id" value="<?=$professorDisciplina['id']?>"/>
							<button class="btn btn-info">Consultar Disciplina</button>
					</form>
				</td>
				
			</tr>
		<?php }?>
</table>
<?php include("rodape.php");?>