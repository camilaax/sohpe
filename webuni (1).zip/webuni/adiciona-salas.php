<?php include("cabecalho.php");?>
<?php include("banco-sala.php");?>
<?php include("logica-usuario.php");
verificaUsuario();?>
	<?php
	$nome=$_POST["nome"];
	$numsala=$_POST['numsala'];
	$bloco=$_POST['bloco'];
	$tipo=$_POST['tipo'];
	if(array_key_exists('usado', $_POST)){
		$usado = "true";
	}
	else{
		$usado = "false";
	}
	?>
	<br><br><br><br>
	<?php
		
		$resultado = insereSala($conexao, $nome, $numsala, $bloco, $tipo, $usado);
		if($resultado){?>
			<p class="alert-success">
				Sala  do Bloco=<?=$bloco?>, Numero=<?=$numsala?> adicionado com sucesso!<br>
			</p>
		<?php 
		}else{
			?>
			<p class "alert-danger">Sala  do Bloco=<?=$bloco?>, Numero=<?=$numsala?> não foi adicionado!<br>
			</p>
		<?php
		}
		mysqli_close($conexao);?>
<?php include("rodape.php");?>
