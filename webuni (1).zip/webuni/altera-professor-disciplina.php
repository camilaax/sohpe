<?php 
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-professor-disciplina.php");
?>

<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="indexadm.php">Home</a>
				<span>Professor/Disciplina</span>
			</div>
		</div>
	</div>
<!-- Page info end -->
		<?php
	$id = $_POST['id'];
	$semestre = $_POST['semestre'];
	$curso_id = $_POST['curso_id'];
	$disciplina_id= $_POST['disciplina_id'];
	$professor_id= $_POST['professor_id'];

	$resultado = alteraProfessorDisciplina($conexao, $id, $semestre,  $curso_id, $disciplina_id, $professor_id);
		if($resultado){?>
			<p class="alert-success">
				Professor/Disciplina alterado com sucesso!<br>
			</p>
		<?php 
		}else{
			?>
			<p class "alert-danger">O professor/disciplina não foi alterado!<br>
			</p>
		<?php
		}
		mysqli_close($conexao);?>
<?php include("rodape.php");?>