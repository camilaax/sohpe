<?php 
  require_once("cabecalho.php"); 
  require_once("conecta.php"); 
  require_once("banco-pe.php"); 

  $id = $_POST['id'];
  $permanencia = buscaPermanencia($conexao, $id);
?>

	<br><br><br><br>
	<h1>Altera P.E</h1>
	<form action="altera-pe.php" method="post">
		<table class="table">
			<input type="hidden" name="id" value="<?=$pe['id']?>"/>
				<tr>
					<td>Nome: </td>
					<td><input class="form-control" type="text" name="nome" value="<?=$pe['nome']?>"/></td><br>
				</tr>
				<tr>
					<td><input class="btn btn-primary" type="submit" value="Cadastrar"/></td><br>
				</tr>
		</table>
	</form>