<?php
include("cabecalho.php"); 
include("conecta.php");
include("banco-pe.php");


$id = $_POST['id']; 
removePermanencia($conexao, $id);

header("Location: permanencia-lista.php?removido=true");
die();

include("rodape.php");
?>






