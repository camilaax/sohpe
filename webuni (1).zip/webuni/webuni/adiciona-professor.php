<?php 
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-professor.php");
include("logica-usuario.php");
verificaUsuario();
?>
<!-- Page info -->
<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Professores</span>
			</div>
		</div>
	</div>
<!-- Page info end -->
		<?php
	
	$nome = $_POST['nome'];
	$email = $_POST['email'];
	$formacao_id= $_POST['formacao_id'];

	
	
		$resultado = insereProfessor($conexao, $nome,  $email, $formacao_id);
		if($resultado){?>
			<p class="alert-success">
				Professor Nome=<?=$nome?> adicionado com sucesso!<br>
			</p>
		<?php 
		}else{
			?>
			<p class "alert-danger">O professor<?=$nome?>não foi adicionado!<br>
			</p>
		<?php
		}
		mysqli_close($conexao);?>
<?php include("rodape.php");?>