<?php 
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-professor.php");
?>

<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Professores</span>
			</div>
		</div>
	</div>
<!-- Page info end -->
		<?php
	$id = $_POST['id'];
	$nome = $_POST['nome'];
	$email = $_POST['email'];
	$formacao_id= $_POST['formacao_id'];
	
		$resultado = alteraProfessor($conexao, $id, $nome, $email,  $formacao_id);
		if($resultado){?>
			<p class="alert-success">
				Professor Nome= <?=utf8_encode($nome)?>  alterado com sucesso!<br>
			</p>
		<?php 
		}else{
			?>
			<p class "alert-danger">O professor<?=utf8_encode($nome)?> não foi alterado!<br>
			</p>
		<?php
		}
		mysqli_close($conexao);?>
<?php include("rodape.php");?>