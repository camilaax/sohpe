
<?php 
  require_once("cabecalho.php"); 
  require_once("conecta.php"); 
  require_once("banco-sala.php");


  $id = $_POST['id'];
 
  $sala = buscaSala($conexao, $id);
 
?>
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Professores</span>
			</div>
		</div>
	</div>
	<br><br><br><br>
	<h1>Altera Sala</h1>
	<form action="altera-sala.php" method="post">
		<table class="table">
			<input type="hidden" name="id" value="<?=$sala['id']?>"/>
				<tr>
					<td>Número: </td>
					<td><input class="form-control" type="number" name="numsala" value="<?=$sala['numsala']?>"/></td><br>
				</tr>
				<tr>
					<td>Bloco</td>
					<td>
						<select name="bloco">
							<?php $essaSala = $sala['bloco'] == "A";
								$selecao = $essaSala ? "selected='selected'" : "";?>
							<option value="A" <?=$selecao?>>A
							<?php $essaSala = $sala['bloco'] == "B";
								$selecao = $essaSala ? "selected='selected'" : "";?>
							<option value="B" <?=$selecao?>>B
							<?php $essaSala = $sala['bloco'] == "C";
								$selecao = $essaSala ? "selected='selected'" : "";?>
							<option value="C" <?=$selecao?>>C
							<?php $essaSala = $sala['bloco'] == "D";
								$selecao = $essaSala ? "selected='selected'" : "";?>
							<option value="D" <?=$selecao?>>D
							<?php $essaSala = $sala['bloco'] == "E";
								$selecao = $essaSala ? "selected='selected'" : "";?>
							<option value="E" <?=$selecao?>>E
							<?php $essaSala = $sala['bloco'] == "M";
								$selecao = $essaSala ? "selected='selected'" : "";?>
							<option value="M" <?=$selecao?>>M
						</select>
					</td>
				</tr>
				<tr>
				<td>Tipo</td>
					<td>
						<select name="tipo">
							<?php $essaSala = $sala['tipo'] == "Sala de aula";
								$selecao = $essaSala ? "selected='selected'" : "";?>
							<option value="Sala de aula" <?=$selecao?>>Sala de aula
							<?php $essaSala = $sala['tipo'] == "Laboratório de Informática";
								$selecao = $essaSala ? "selected='selected'" : "";?>
							<option value="Laboratório de Informática" <?=$selecao?>>Laboratório de Informática
							<?php $essaSala = $sala['tipo'] == "Laboratório de Mecânica";
								$selecao = $essaSala ? "selected='selected'" : "";?>
							<option value="Laboratório de Mecânica" <?=$selecao?>>Laboratório de Mecânica
							<?php $essaSala = $sala['tipo'] == "Laboratório de Eletrotécnica";
								$selecao = $essaSala ? "selected='selected'" : "";?>
							<option value="Laboratório de Eletrotécnica" <?=$selecao?>>Laboratório de Eletrotécnica
							<?php $essaSala = $sala['tipo'] == "Laboratório de Biologia";
								$selecao = $essaSala ? "selected='selected'" : "";?>
							<option value="Laboratório de Biologia" <?=$selecao?>>Laboratório de Biologia
							<?php $essaSala = $sala['tipo'] == "Laboratório de Física";
								$selecao = $essaSala ? "selected='selected'" : "";?>
							<option value="Laboratório de Física" <?=$selecao?>>Laboratório de Física
							<?php $essaSala = $sala['tipo'] == "Laboratório de Química";
								$selecao = $essaSala ? "selected='selected'" : "";?>
							<option value="Laboratório de Química" <?=$selecao?>>Laboratório de Química
						</select>
					</td>
				</tr>
				<tr>
					<td><input class="btn btn-primary" type="submit" value="Alterar"/></td><br>
				</tr>
		</table>
	</form>


<?php include("rodape.php"); ?>