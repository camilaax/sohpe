<?php include("cabecalho.php");?>
<?php include("conecta.php");?>
<?php include("banco-disciplina.php");?>
<?php include("logica-usuario.php");
verificaUsuario();?>

	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Disciplina</span>
			</div>
		</div>
	</div>
	<?php
	$nome=$_POST['nome'];
		
		$resultado = insereDisciplina($conexao, $nome);
		if($resultado){?>
			<p class="alert-success">
				Disciplina=<?=$nome?> adicionada com sucesso!<br>
			</p>
		<?php 
		}else{
			?>
			<p class "alert-danger">Disciplina=<?=$nome?> não foi adicionada!<br>
			</p>
		<?php
		}
		mysqli_close($conexao);?>
<?php include("rodape.php");?>
