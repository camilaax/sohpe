
<?php 

 include("conecta.php"); 
 include("banco-pe.php");
  include("banco-sala.php");
  include("banco-professor.php");
include("MPDF57/mpdf.php");
$idProf = $_GET['id'];



$professor = buscaProfessor($conexao, $idProf);
$permanencias = listaPermanenciasProf($conexao, $idProf);


 
   $titulo = "Permanências do professor: ";
   $titulo .= "{$professor['nome']}"; 

   $imagem = "logo.png";
    $color  = false;  

      $retorno = "";  
	  $retorno .= "<div><img src=".$imagem."></div>";
 
      $retorno .= "<h2 style=\"text-align:center\">{$titulo}</h2>";  
      $retorno .= "<table border='1' width='1000' align='center'>  
           <tr>  
					<th><h6>HORA INÍCIO</h6></th>
					<th><h6>HORA TÉRMINO</h6></th>
					<th><h6>SEMESTRE</h6></th>
					<th><h6>DIA DA SEMANA</h6></th>
					<th><h6>SALA</h6></th>
           </tr>";  
		

 
  
	  foreach($permanencias as $permanencia): 
	   $retorno .= ($color) ? "<tr>" : "<tr class=\"fundo\">"; 
		$idSala = $permanencia['sala_id'];
		$sala = buscaSala($conexao, $idSala);
		$retorno .= "<td>{$permanencia['horainicio']}</td>"; 
        $retorno .= "<td>{$permanencia['horatermino']}</td>";  
		$retorno .= "<td>{$permanencia['semestre']}</td>";  
		$retorno .= "<td>{$permanencia['diasemana']}</td>";  
		$retorno .= "<td>{$sala['bloco']}{$sala['numsala']}</td>";  
		
		 
       $retorno .= "</tr>";  
	   $color = !$color; 

      endforeach;  
 
      $retorno .= "</table>";  

	$mpdf = new mPDF(['format' => 'utf-8', [190, 236]]);
	$mpdf->AddPage('L');
	 $mpdf->SetDisplayMode('fullpage');
	 $css = file_get_contents("estilo.css");
	 $mpdf->WriteHTML($css,1);
	 $mpdf->WriteHTML($retorno);
	 $mpdf->Output(); 


	 ?>
	

 