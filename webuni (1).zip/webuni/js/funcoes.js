
function Mudarestado1(el1,el2,el3) {
        var display = document.getElementById(el1).style.display;
        document.getElementById(el1).style.display = 'block';
		var display = document.getElementById(el2).style.display;
        document.getElementById(el2).style.display = 'none';
		var display = document.getElementById(el3).style.display;
        document.getElementById(el3).style.display = 'none';
    }
	
function Mudarestado2(el1,el2,el3) {
         var display = document.getElementById(el1).style.display;
        document.getElementById(el1).style.display = 'none';
		var display = document.getElementById(el2).style.display;
        document.getElementById(el2).style.display = 'block';
		var display = document.getElementById(el3).style.display;
        document.getElementById(el3).style.display = 'none';
    }

function Mudarestado3(el1,el2,el3) {
        var display = document.getElementById(el1).style.display;
        document.getElementById(el1).style.display = 'none';
		var display = document.getElementById(el2).style.display;
        document.getElementById(el2).style.display = 'none';
		var display = document.getElementById(el3).style.display;
        document.getElementById(el3).style.display = 'block';
    }
	
function Mudarestado(el1,el2,el3) {
        var display = document.getElementById(el1).style.display;
        if(display == "none"){
            document.getElementById(el1).style.display = 'block';
			var display = document.getElementById(el3).style.display;
			document.getElementById(el3).style.display = 'none';

		}
        else{
            document.getElementById(el1).style.display = 'none';
			var display = document.getElementById(el3).style.display;
			document.getElementById(el3).style.display = 'block';
		}

    }
	

function deixarOculto(id){
document.getElementById(id).style.display = "none";
}

function mostraOculto(id){
	 if(document.getElementById(id).style.display == "none"){
	document.getElementById(id).style.display = "inline";
	}else{
	document.getElementById(id).style.display = "none";
}
}