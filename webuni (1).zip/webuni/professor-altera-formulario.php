
<?php 
  require_once("cabecalho.php"); 
  require_once("conecta.php"); 
  require_once("banco-professor.php");
	require_once("banco-formacao.php");

  $id = $_POST['id'];
 
  $professor = buscaProfessor($conexao, $id);
  $formacoes=listaFormacoes($conexao);
 
?>
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Professores</span>
			</div>
		</div>
	</div>
	<br><br><br><br>
	<h1>Altera Professor</h1>
	<form action="altera-professor.php" method="post">
		<table class="table">
			<input type="hidden" name="id" value="<?=$professor['id']?>"/>
				<tr>
					<td>Nome: </td>
					<td><input class="form-control" type="text" name="nome" value="<?=$professor['nome']?>"/></td><br>
				</tr>
				<tr>
					<td>E-MAIL </td>
					<td><input class="form-control" type="text" name="email" value="<?=$professor['email']?>"/></td><br>
				</tr>
				<tr>
					<td>Área de atuação: </td>
					<td>
						<select name="formacao_id" class="form-control">
							<?php foreach($formacoes as $formacao) : 
								$essaFormacao = $professor['formacao_id'] == $formacao['id'];
								$selecao = $essaFormacao ? "selected='selected'" : "";
							?>
							<option value="<?=$formacao['id']?>" <?=$selecao?>><?=utf8_encode($formacao['nome'])?>
							</option>
							<?php endforeach ?>
						</select>
					</td>
				</tr>
				<tr>
				<tr>
					<td><input class="btn btn-primary" type="submit" value="Alterar"/></td><br>
				</tr>
		</table>
	</form>


<?php include("rodape.php"); ?>

