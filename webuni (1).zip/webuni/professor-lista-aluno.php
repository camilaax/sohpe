<?php 
require_once("cabecalhoaluno.php");
require_once("conecta.php");
require_once("banco-professor.php");
$professores = listaProfessores($conexao);
?>
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="indexaluno.php">Home</a>
				<span>Professores</span>
			</div>
		</div>
	</div>

<!-- Page info -->



<!-- Page info end -->
<table class="table table-striped table-bordered">
	<tr>
		<th><h4>Nome</h4></th>
		<th><h4>E-mail</h4></th>
		<th><h4>Área de atuação</h4></th>
		
	
	<?php
	
		foreach($professores as $professor){
			?>
			<tr>
				<td><?=$professor['nome']?></td>
				<td><?=$professor['email']?></td>
				<td><?=utf8_encode($professor['formacao_nome'])?></td>
			</tr>
		<?php }?>
</table>
<?php include("rodape.php");?>