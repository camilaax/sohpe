<?php
include("cabecalho.php");
?>
	<!-- Header section end -->


	<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/1.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="#">Home</a>
				<span>Cursos</span>
			</div>
		</div>
	</div>
	<!-- Page info end -->


	<!-- search section -->
	<section class="search-section ss-other-page">
		<div class="container">
			<div class="search-warp">
				<div class="section-title text-white">
					<h2><span>Escolha seu Curso</span></h2>
				</div>
				<div class="row">
					<div class="col-lg-10 offset-lg-1">
						<!-- search form -->
						<form class="course-search-form">
							<input type="text" placeholder="Curso">
							<button class="site-btn btn-dark">Procurar Curso</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- search section end -->


	<!-- course section -->
	<section class="course-section spad pb-0">
		<div class="course-warp">
			<ul class="course-filter controls">
				<li class="control active" data-filter="all">Todos</li>
				<li class="control" data-filter=".medio">Medio</li>
				<li class="control" data-filter=".superior">Superior</li>
				<li class="control" data-filter=".subsequente">Subsequente</li>
			</ul>                                       
			<div class="row course-items-area">
				<!-- course -->
				<div class="mix col-lg-3 col-md-4 col-sm-6 medio">
					<div class="course-item">
						<div class="course-thumb set-bg" data-setbg="img/courses/1.jpg">
						</div>
						<div class="course-info">
							<div class="course-text">
								<h5>Tecnico em Eletrotecnica</h5>
								<p>Curso Tecnico Medio Integrado em Eletrotecnica</p>
							</div>
						</div>
					</div>
				</div>
				<!-- course -->
				<div class="mix col-lg-3 col-md-4 col-sm-6 medio">
					<div class="course-item">
						<div class="course-thumb set-bg" data-setbg="img/courses/f-2.jpg">
						</div>
						<div class="course-info">
							<div class="course-text">
								<h5>Tecnico em Informatica</h5>
								<p>Curso Tecnico Medio Integrado em Informatica</p>
							</div>
						</div>
					</div>
				</div>
				<!-- course -->
				<div class="mix col-lg-3 col-md-4 col-sm-6 medio">
					<div class="course-item">
						<div class="course-thumb set-bg" data-setbg="img/courses/3.jpg">
						</div>
						<div class="course-info">
							<div class="course-text">
								<h5>Tecnico em Mecanica</h5>
								<p>Curso Tecnico Medio Integrado em Mecanica</p>
							</div>
						</div>
					</div>
				</div>
				<!-- course -->
				<div class="mix col-lg-3 col-md-4 col-sm-6 superior">
					<div class="course-item">
						<div class="course-thumb set-bg" data-setbg="img/courses/8.jpg">
						</div>
						<div class="course-info">
							<div class="course-text">
								<h5>Tecnologo em Sistemas Para Internet</h5>
								<p>Curso Superior em Sistemas Para Internet</p>
							</div>
						</div>
					</div>
				</div>
				<!-- course -->
				<div class="mix col-lg-3 col-md-4 col-sm-6 subsequente">
					<div class="course-item">
						<div class="course-thumb set-bg" data-setbg="img/courses/6.jpg">
						</div>
						<div class="course-info">
							<div class="course-text">
								<h5>Tecnico em Mecanica</h5>
								<p>Curso Tecnico em Mecanica</p>
							</div>
						</div>
					</div>
				</div>
				
				
				<!-- course -->
				<div class="mix col-lg-3 col-md-4 col-sm-6 subsequente">
					<div class="course-item">
						<div class="course-thumb set-bg" data-setbg="img/courses/4.jpg">
						</div>
						<div class="course-info">
							<div class="course-text">
								<h5>Tecnico em Eletrotecnica</h5>
								<p>Curso Tecnico em Eletrotecnica</p>
							</div>
						</div>
					</div>
				</div>
				<!-- course -->
				<div class="mix col-lg-3 col-md-4 col-sm-6 subsequente">
					<div class="course-item">
						<div class="course-thumb set-bg" data-setbg="img/courses/5.jpg">
						</div>
						<div class="course-info">
							<div class="course-text">
								<h5>Tecnico em Informatica</h5>
								<p>Curso Tecnico em Informatica</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- course section end -->

<?php
include("rodape.php");
?>