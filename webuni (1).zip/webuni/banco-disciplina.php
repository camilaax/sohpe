<?php	

function listaDisciplinas($conexao){
	$disciplinas = array();
	$query = "select * from disciplinas order By nome ASC";
	$resultado = mysqli_query($conexao, $query);
	while($disciplina = mysqli_fetch_assoc($resultado)){
		array_push($disciplinas, $disciplina);
	}
	return $disciplinas;
}
function insereDisciplina($conexao, $nome){
	$query="insert into disciplinas(nome) values('{$nome}')";
	$resultadoDaInsercao= mysqli_query($conexao, $query);
	return $resultadoDaInsercao;
}
function buscaDisciplina($conexao, $id){
	$query = "select * from disciplinas where id={$id}";
	$resultado = mysqli_query($conexao, $query);
	return mysqli_fetch_assoc($resultado);
}
function removeDisciplinas($conexao,$id){
	$query = "delete from disciplinas where id={$id}";
	return mysqli_query($conexao,$query);
}
function alteraDisciplina($conexao,$id,$nome) {
	$query = "update disciplinas set nome = '{$nome}' where id = '{$id}'";
	return mysqli_query($conexao, $query);
}?>