<br>
<br>
<?php require_once("cabecalho.php");?>
<?php require_once("banco-curso.php");?>
<?php //include("logica-usuario.php");
//verificaUsuario();?>
<?php
	$id=$_POST['id'];
	removeCurso($conexao, $id);
header("Location: curso-lista.php?removido=true");
die();

