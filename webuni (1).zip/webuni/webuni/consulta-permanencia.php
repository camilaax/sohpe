<?php 
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-professor.php");
require_once("banco-disciplina.php");
require_once("banco-pe.php");
require_once("banco-sala.php");
$filtro=$_POST['filtro'];
?>
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Permanência</span>
			</div>
		</div>
	</div>
<?php

	switch ($filtro) {
		case 1:
				$professor_id = $_POST['professor_id'];
				$permanencias = listaPermanenciasProf($conexao, $professor_id); 
				$professor = buscaProfessor($conexao, $professor_id);?>
				<h2>Professor: <?=$professor['nome']?></h2>
				<table class="table table-striped table-bordered">
					<tr>
						<th><h4>Hora Início</h4></th>
						<th><h4>Hora Término</h4></th>
						<th><h4>Semestre</h4></th>
						<th><h4>Dia da Semana</h4></th>
						<th><h4>Sala</h4></th>
					<?php
						foreach($permanencias as $permanencia){
							?>
							<tr>
								<td><?=$permanencia['horainicio']?></td>
								<td><?=$permanencia['horatermino']?></td>
								<td><?=$permanencia['semestre']?></td>
								<td><?=$permanencia['diasemana']?></td>
								<td><?=$permanencia['sala_bloco']?><?=$permanencia['sala_numsala']?></td>
							</tr>
						<?php }?>
				</table>
				
			   <?php break;
		case 2:
				$disciplina_id = $_POST['disciplina_id'];
				$permanencias = listaPermanenciasDisc($conexao, $disciplina_id); 
				$disciplina = buscaDisciplina($conexao, $disciplina_id);?>
				<h2>Disciplina: <?=$disciplina['nome']?></h2>
				<table class="table table-striped table-bordered">
					<tr>
						<th><h4>Hora Início</h4></th>
						<th><h4>Hora Término</h4></th>
						<th><h4>Semestre</h4></th>
						<th><h4>Dia da Semana</h4></th>
						<th><h4>Sala</h4></th>
						<th><h4>Professor</h4></th>
					<?php
						foreach($permanencias as $permanencia){
							?>
							<tr>
								<td><?=$permanencia['horainicio']?></td>
								<td><?=$permanencia['horatermino']?></td>
								<td><?=$permanencia['semestre']?></td>
								<td><?=$permanencia['diasemana']?></td>
								<td><?=$permanencia['sala_bloco']?><?=$permanencia['sala_numsala']?></td>
								<td><?=$permanencia['professor_nome']?></td>
							</tr>
						<?php }?>
				</table>
				
			   <?php break;
		case 3:
				$sala_id = $_POST['sala_id'];
				$permanencias = listaPermanenciasSala($conexao, $sala_id); 
				$sala = buscaSala($conexao, $sala_id);?>
				<h2>Sala: <?=$sala['bloco']?><?=$sala['numsala']?></h2>
				<table class="table table-striped table-bordered">
					<tr>
						<th><h4>Hora Início</h4></th>
						<th><h4>Hora Término</h4></th>
						<th><h4>Semestre</h4></th>
						<th><h4>Dia da Semana</h4></th>
						<th><h4>Professor</h4></th>
					<?php
						foreach($permanencias as $permanencia){
							?>
							<tr>
								<td><?=$permanencia['horainicio']?></td>
								<td><?=$permanencia['horatermino']?></td>
								<td><?=$permanencia['semestre']?></td>
								<td><?=$permanencia['diasemana']?></td>
								<td><?=$permanencia['professor_nome']?></td>
							</tr>
						<?php }?>
				</table>
				
			   <?php break;
	}

?>


<?php include("rodape.php");?>