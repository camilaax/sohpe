<?php 
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-curso.php");
require_once("banco-professor.php");
require_once("banco-disciplina.php");
$cursos = listaCursos($conexao);
$professores = listaProfessores($conexao);
$disciplinas = listaDisciplinas($conexao);
?>
<?php
	if(array_key_exists("adicionado",$_GET)&& ($_GET['adicionado']=='true')){
?>
	<p class="alert-success">Professor/Disciplina adicionado com sucesso.</p>
<?php } ?>
<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Professores/Disciplina</span>
			</div>
		</div>
	</div>
<!-- Page info end -->

<h1>Formulário de cadastro</h1>
<form action="" method="post" name="cadastrar">

	<div class="row">
		<div class="col-sm-2">
				<fieldset>
					<legend>Semestre</legend>
					<select name="semestre" autofocus>
						<option value="2019-2">2019-2
						<option value="2020-1">2020-1
						<option value="2020-2">2020-2
						<option value="2021-1">2021-1
					</select>
				</fieldset>
		</div>
		<div class="col-sm-3">
				<fieldset>
					<legend>Curso</legend>
					<select name="curso_id">
						<?php foreach($cursos as $curso) : ?>
						<option value="<?=$curso['id']?>"><?=$curso['nome']?></option>
						<?php endforeach ?>
					</select>
				</fieldset>
		</div>
		<div class="col-sm-3">
				<fieldset>
					<legend>Disciplina</legend>
					<select name="disciplina_id">
						<?php foreach($disciplinas as $disciplina) : ?>
						<option value="<?=$disciplina['id']?>"><?=$disciplina['nome']?></option>
						<?php endforeach ?>
					</select>
				</fieldset>
		</div>
		<div class="col-sm-3">
				<fieldset>
					<legend>Professor</legend>
					<select name="professor_id">
						<?php foreach($professores as $professor) : ?>
						<option value="<?=$professor['id']?>"><?=$professor['nome']?></option>
						<?php endforeach ?>
					</select>
				</fieldset>
		</div>
		<div class="col-sm-1">
			<fieldset>
				<legend>Cadastro</legend>
				<td><input class="btn btn-dark" type="submit" name="cadastrar" value="Cadastrar" /> <td>
			</fieldset>
		</div>
	</div>
</form>	
<?php
	if(isset($_POST['cadastrar'])){
		$semestre=$_POST["semestre"];
		$curso_id=$_POST["curso_id"];
		$professor_id=$_POST["professor_id"];
		$disciplina_id=$_POST["disciplina_id"];
		$query="insert into professordisciplina(semestre, curso_id, professor_id, disciplina_id) values
							               ('{$semestre}',{$curso_id},{$professor_id},{$disciplina_id})";
		$resultadoDaInsercao= mysqli_query($conexao, $query);
	}
?>

<?php 
require_once("rodape.php");
?>