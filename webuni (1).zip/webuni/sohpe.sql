-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 25-Nov-2019 às 17:25
-- Versão do servidor: 10.1.30-MariaDB
-- PHP Version: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sohpe`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cursos`
--

CREATE TABLE `cursos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cursos`
--

INSERT INTO `cursos` (`id`, `nome`) VALUES
(1, 'TÃ©cnico em InformÃ¡tica'),
(2, 'TÃ©cnico em EletrotÃ©cnica'),
(3, 'Tecnologia em Sistemas para Internet');

-- --------------------------------------------------------

--
-- Estrutura da tabela `disciplinas`
--

CREATE TABLE `disciplinas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `disciplinas`
--

INSERT INTO `disciplinas` (`id`, `nome`) VALUES
(1, 'Desenvolvimento Web 1'),
(2, 'Desenvolvimento Web 2'),
(3, 'EducaÃ§Ã£o FÃ­sica'),
(4, 'EducaÃ§Ã£o FÃ­sica 2');

-- --------------------------------------------------------

--
-- Estrutura da tabela `formacoes`
--

CREATE TABLE `formacoes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(50) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `formacoes`
--

INSERT INTO `formacoes` (`id`, `nome`) VALUES
(1, 'Administração'),
(2, 'Biologia'),
(3, 'Educação Física'),
(4, 'Eletrônica'),
(5, 'Filosofia'),
(6, 'Física'),
(7, 'Geografia'),
(8, 'História'),
(9, 'Informática - Desenvolvimento'),
(10, 'Informática - Engenharia de Software'),
(11, 'Informática - Redes'),
(12, 'Língua Estrangeira Moderna - Espanhol'),
(13, 'Língua Estrangeira Moderna - Inglês'),
(14, 'Língua Portuguesa'),
(15, 'Língua Portuguesa - Literatura'),
(17, 'Matemática'),
(18, 'Mecânica'),
(19, 'Metodologia'),
(20, 'Química'),
(21, 'Sociologia');

-- --------------------------------------------------------

--
-- Estrutura da tabela `permanencias`
--

CREATE TABLE `permanencias` (
  `id` int(11) NOT NULL,
  `horainicio` time NOT NULL,
  `horatermino` time NOT NULL,
  `semestre` varchar(6) NOT NULL,
  `diasemana` varchar(30) NOT NULL,
  `sala_id` int(11) NOT NULL,
  `professor_id` int(11) NOT NULL,
  `numdia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `permanencias`
--

INSERT INTO `permanencias` (`id`, `horainicio`, `horatermino`, `semestre`, `diasemana`, `sala_id`, `professor_id`, `numdia`) VALUES
(2, '20:23:00', '21:23:00', '2019-2', 'Sexta-feira', 1, 1, 5),
(4, '17:31:00', '18:36:00', '2019-2', 'Sexta-feira', 3, 2, 5),
(5, '19:48:00', '22:48:00', '2019-2', 'Segunda-feira', 1, 3, 1),
(6, '17:57:00', '23:57:00', '2019-2', 'TerÃ§a-feira', 1, 3, 2),
(7, '10:59:00', '20:59:00', '2019-2', 'Quarta-feira', 3, 3, 3),
(8, '10:31:00', '11:31:00', '2019-2', 'Quinta-feira', 3, 2, 5),
(9, '02:08:00', '03:08:00', '2019-2', 'Quarta-feira', 3, 4, 3),
(10, '23:58:00', '23:58:00', '2019-2', 'Quarta-feira', 3, 5, 3),
(11, '11:47:00', '12:47:00', '2019-2', 'Segunda-feira', 1, 1, 1),
(12, '10:00:00', '10:58:00', '2019-2', 'Segunda-feira', 1, 1, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `professordisciplina`
--

CREATE TABLE `professordisciplina` (
  `id` int(11) NOT NULL,
  `semestre` varchar(6) NOT NULL,
  `curso_id` int(11) NOT NULL,
  `professor_id` int(11) NOT NULL,
  `disciplina_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `professordisciplina`
--

INSERT INTO `professordisciplina` (`id`, `semestre`, `curso_id`, `professor_id`, `disciplina_id`) VALUES
(1, '2021-2', 3, 3, 2),
(2, '2021-2', 1, 1, 1),
(3, '2019-2', 3, 3, 1),
(4, '2019-2', 3, 3, 1),
(6, '2019-2', 1, 1, 2),
(7, '2019-2', 1, 1, 1),
(8, '2019-2', 1, 2, 1),
(9, '2019-2', 1, 1, 1),
(10, '2019-2', 1, 4, 1),
(11, '2019-2', 1, 4, 1),
(12, '2019-2', 1, 5, 3),
(13, '2019-2', 2, 5, 4),
(14, '2019-2', 1, 2, 1),
(15, '2019-2', 1, 4, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `professores`
--

CREATE TABLE `professores` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `formacao_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `professores`
--

INSERT INTO `professores` (`id`, `nome`, `email`, `formacao_id`) VALUES
(1, 'Elaine', 'elaine.cassiano@ifms.edu.br', 1),
(2, 'Robson', 'robson', 3),
(3, 'ClÃ¡udia', 'claudia.fernandes@ifms.edu.br', 9),
(4, 'Maria ', 'maria@ifms.edu.br', 12),
(5, 'JosÃ©', 'jose@ifms.edu.br', 17);

-- --------------------------------------------------------

--
-- Estrutura da tabela `salas`
--

CREATE TABLE `salas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `numsala` int(11) NOT NULL,
  `bloco` varchar(5) NOT NULL,
  `tipo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `salas`
--

INSERT INTO `salas` (`id`, `numsala`, `bloco`, `tipo`) VALUES
(1, 201, 'A', 'Sala de aula'),
(3, 202, 'C', 'LaboratÃ³rio de InformÃ¡tica');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `login` varchar(20) NOT NULL,
  `senha` varchar(100) NOT NULL,
  `tipo` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `login`, `senha`, `tipo`) VALUES
(1, 'camila@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'administrador');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `disciplinas`
--
ALTER TABLE `disciplinas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `formacoes`
--
ALTER TABLE `formacoes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `permanencias`
--
ALTER TABLE `permanencias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `professordisciplina`
--
ALTER TABLE `professordisciplina`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `professores`
--
ALTER TABLE `professores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salas`
--
ALTER TABLE `salas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cursos`
--
ALTER TABLE `cursos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `disciplinas`
--
ALTER TABLE `disciplinas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `formacoes`
--
ALTER TABLE `formacoes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `permanencias`
--
ALTER TABLE `permanencias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `professordisciplina`
--
ALTER TABLE `professordisciplina`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `professores`
--
ALTER TABLE `professores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `salas`
--
ALTER TABLE `salas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
