<?php include("cabecalho.php");?>
<?php include("banco-sala.php");?>
<?php include("logica-usuario.php");
verificaUsuario();?>

	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="indexadm.php">Home</a>
				<span>Salas</span>
			</div>
		</div>
	</div>
	<?php
	$numsala=$_POST['numsala'];
	$bloco=$_POST['bloco'];
	$tipo=$_POST['tipo'];
		
		$resultado = insereSala($conexao, $numsala, $bloco, $tipo);
		if($resultado){?>
			<p class="alert-success">
				Sala  do Bloco=<?=$bloco?>, Numero=<?=$numsala?> adicionada com sucesso!<br>
			</p>
		<?php 
		}else{
			?>
			<p class "alert-danger">Sala  do Bloco=<?=$bloco?>, Numero=<?=$numsala?> não foi adicionado!<br>
			</p>
		<?php
		}
		mysqli_close($conexao);?>
<?php include("rodape.php");?>

