<?php 
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-formacao.php");
$formacoes = listaFormacoes($conexao);
?>
<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Professores</span>
			</div>
		</div>
	</div>
<!-- Page info end -->
	<h1>Formulário de cadastro</h1>
	<form action="adiciona-professor.php" method="post">
		<table>
			<tr>
				<td>Nome: </td>
				<td><input class="form-control" type="text" name="nome"/></td><br>
			</tr>
			<tr>
				<td>Área de atuação: </td>
				<td>
					<select name="formacao_id">
					<?php foreach($formacoes as $formacao) : ?>
					<option value="<?=$formacao['id']?>"><?=utf8_encode($formacao['nome'])?></option>
					<?php endforeach ?>
					</select>
				</td>
			</tr>
				</td>
			</tr>
			<tr>
				<td>E-mail: </td>
				<td><input class="form-control" type="text" name="email"/></td><br>
			</tr>
			<tr>
				<td><input class="btn btn-primary" type="submit" value="Cadastrar"/></td><br>
			</tr>
		</table>
	</form>
<?php include("rodape.php");?>