<?php	

function listaPermanencias($conexao){
	$permanencias = array();
	$query = "select pe.*, p.nome as professor_nome, s.bloco as sala_bloco, s.numsala as sala_numsala
					from permanencias as pe 
					join professores as p on pe.professor_id  = p.id
					join salas as s on pe.sala_id = s.id";
	$resultado = mysqli_query($conexao, $query);
	while($permanencia = mysqli_fetch_assoc($resultado)){
		array_push($permanencias, $permanencia);
	}
	return $permanencias;
}
function inserePermanencias($conexao, $horainicio,$horatermino, $semestre, $diasemana, $sala_id, $professor_id, $numdia){
	$query="insert into permanencias(horainicio, horatermino, semestre, diasemana, sala_id, professor_id, numdia) values
	                     ('{$horainicio}', '{$horatermino}', '{$semestre}', '{$diasemana}', {$sala_id},{$professor_id}, {$numdia})";
	$resultadoDaInsercao= mysqli_query($conexao, $query);
	return $resultadoDaInsercao;
}

function buscaPermanencia($conexao, $id){
	$query = "select * from permanencias where id={$id}";
	$resultado = mysqli_query($conexao, $query);
	return mysqli_fetch_assoc($resultado);
}
function removePermanencia($conexao, $id){
	$query = "delete from permanencias where id={$id}";
	return mysqli_query($conexao,$query);
}

function alteraPermanencia($conexao,$id, $horainicio,$horatermino, $semestre, $diasemana, $sala_id, $professor_id) {
	$query = "update permanencias set horainicio='{$horainicio}',horatermino='{$horatermino}', semestre=  '{$semestre}', diasemana = '{$diasemana}',
				sala_id = {$sala_id},professor_id = {$professor_id}
				where id = '{$id}'"; 
	return mysqli_query($conexao, $query);
}


function listaPermanenciasProf($conexao, $professor_id){
	$permanencias = array();
	$query = "select pe.*, p.nome as professor_nome, s.bloco as sala_bloco, s.numsala as sala_numsala
					from permanencias as pe 
					join professores as p on pe.professor_id  = p.id 
					join salas as s on pe.sala_id = s.id
					where pe.professor_id = {$professor_id} order by numdia,horainicio ASC";
	$resultado = mysqli_query($conexao, $query);
	while($permanencia = mysqli_fetch_assoc($resultado)){
		array_push($permanencias, $permanencia);
	}
	return $permanencias;
}

function listaPermanenciasDisc($conexao, $disciplina_id){
	$permanencias = array();
	$query = "select pe.*, p.nome as professor_nome, s.bloco as sala_bloco, s.numsala as sala_numsala
					from permanencias as pe 
					join professores as p on pe.professor_id  = p.id 
					join salas as s on pe.sala_id = s.id
					join professordisciplina as pd on pe.professor_id = pd.professor_id
					where pd.disciplina_id = {$disciplina_id} order by numdia,horainicio ASC";
	$resultado = mysqli_query($conexao, $query);
	while($permanencia = mysqli_fetch_assoc($resultado)){
		array_push($permanencias, $permanencia);
	}
	return $permanencias;
}

function listaPermanenciasSala($conexao, $sala_id){
	$permanencias = array();
	$query = "select pe.*, p.nome as professor_nome, s.bloco as sala_bloco, s.numsala as sala_numsala
					from permanencias as pe 
					join professores as p on pe.professor_id  = p.id 
					join salas as s on pe.sala_id = s.id
					where pe.sala_id = {$sala_id} order by numdia,horainicio ASC";
	$resultado = mysqli_query($conexao, $query);
	while($permanencia = mysqli_fetch_assoc($resultado)){
		array_push($permanencias, $permanencia);
	}
	return $permanencias;
}
?>