<?php 
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-sala.php");
?>

<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Salas</span>
			</div>
		</div>
	</div>
<!-- Page info end -->
		<?php
	$id = $_POST['id'];
	$numsala = $_POST['numsala'];
	$bloco = $_POST['bloco'];
	$tipo= $_POST['tipo'];
	
		$resultado = alteraSala($conexao,$id,$numsala,$bloco,$tipo);
		if($resultado){?>
			<p class="alert-success">
				Sala= <?=$bloco?><?=$numsala?>  alterada com sucesso!<br>
			</p>
		<?php 
		}else{
			?>
			<p class "alert-danger">Sala= <?=$bloco?><?=$numsala?> não foi alterado!<br>
			</p>
		<?php
		}
		mysqli_close($conexao);?>
<?php include("rodape.php");?>