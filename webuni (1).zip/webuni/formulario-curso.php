<?php 
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-curso.php");
?>
<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/1.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="indexadm.php">Home</a>
				<span>Cursos</span>
			</div>
		</div>
	</div>
<!-- Page info end -->

	<br><br><br><br>
	<section class="search-section ss-other-page">
		<div class="container">
			<div class="section-title text-white">
				<h2><span>Formulario de cadastro de cursos</span></h2>
			</div>
			<div class="row">
				<div class="col-lg-10 offset-lg-1">
					<form action="adiciona-curso.php" method="post">
						<table>
							<tr>
								<td>Nome: </td>
								<td><input class="form-control" type="text" name="nome"/></td><br>
							</tr>
				
							<tr>
								<td><input class="site-btn btn-dark"type="submit" value="Cadastrar"/></td><br>
							</tr>
						</table>
					</form>
				</div>
			</div>	
		</div>
	</section>
<?php include("rodape.php");?>