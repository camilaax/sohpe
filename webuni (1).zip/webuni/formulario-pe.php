<?php 
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-professor.php");
require_once("banco-sala.php");
$professores = listaProfessores($conexao);
$salas = listaSalas($conexao);
?>
<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="indexadm.php">Home</a>
				<span>Permanência</span>
			</div>
		</div>
	</div>
<!-- Page info end -->

<h3>Formulário de cadastro</h3>
<form action="adiciona-pe.php" method="post" >
<table>
	<tr>
		<td>Horário de Início</td>
		<td><input class="form-control" type="time" name="horainicio"/></td>
	</tr>
	<tr>
		<td>Horário de Término</td>
		<td><input class="form-control" type="time" name="horatermino"/></td>
	</tr>
	<tr>
		<td> Semestre</td>
		<td>
			<select class="form-control" name="semestre">
				<option value="2019-2">2019-2
				<option value="2020-1">2020-1
				<option value="2020-2">2020-2
				<option value="2021-1">2021-1
				<option value="2021-1">2022-2
			</select>
		</td>
	</tr>
	<tr>
		<td>Dia da semana</td>
		<td>
			<select class="form-control" name="diasemana">
				<option value="Segunda-feira">Segunda-feira
				<option value="Terça-feira">Terça-feira
				<option value="Quarta-feira">Quarta-feira
				<option value="Quinta-feira">Quinta-feira
				<option value="Sexta-feira">Sexta-feira
				<option value="Sábado">Sábado
			</select>
		</td>
	</tr>
	<tr>
	<td>Sala</td>
		<td>
			<select class="form-control" name="sala_id">
				<?php foreach($salas as $sala) : 
				$num=(string) $sala['numsala'];
				$total = $sala['bloco'] . $num ?>
				<option value="<?=$sala['id']?>"><?=$total?></option>
				<?php endforeach ?>
			</select>
		</td>
	</tr>
		<tr>
		<td>Professor</td>
		<td>
			<select class="form-control" name="professor_id">
				<?php foreach($professores as $professor) : ?>
				<option value="<?=$professor['id']?>"><?=$professor['nome']?></option>
				<?php endforeach ?>
			</select>
		</td>
	</tr>
	<tr>
		<td><input class="btn btn-dark" type="submit" name="cadastrar" value="Cadastrar" /> <td>
	</tr>
</table>
</form>	

<?php
	require_once("rodape.php");
?>