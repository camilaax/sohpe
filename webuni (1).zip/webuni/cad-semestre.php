
	<form  action="adiciona-professor-disciplina.php">

				<?php $semestre = $_POST["semestre"]; ?>

		<input type="hidden" name="semestre" value="<?=$semestre?>"/>
		<tr>
			<td>Curso: </td>
			<td>
				<select name="curso_id">
					<?php foreach($cursos as $curso) : ?>
					<option value="<?=$curso['id']?>"><?=utf8_encode($curso['nome'])?></option>
					<?php endforeach ?>
				</select>
			</td>
		</tr>
		<tr>
			<input type="button" value="Avançar" />
		</tr>
		</div>
	</form>
<?php include("rodape.php");?>