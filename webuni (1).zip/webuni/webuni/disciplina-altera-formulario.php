<?php 
  require_once("cabecalho.php"); 
  require_once("conecta.php"); 
  require_once("banco-disciplina.php");

  $id = $_POST['id'];
 
  $disciplina = buscaDisciplina($conexao, $id);

?>
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Disciplinas</span>
			</div>
		</div>
	</div>

	
	<h1>Altera Disciplina</h1>
	<form action="altera-disciplina.php" method="post">
		<table class="table">
			<input type="hidden" name="id" value="<?=$disciplina['id']?>"/>
				<tr>
					<td>Nome: </td>
					<td><input class="form-control" type="text" name="nome" value="<?=$disciplina['nome']?>"/></td><br>
				</tr>
				
				<tr>
					<td><input class="btn btn-dark" type="submit" value="Alterar"/></td><br>
				</tr>
		</table>
	</form>


<?php include("rodape.php"); ?>