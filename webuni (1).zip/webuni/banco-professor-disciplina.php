<?php	


function listaProfessorDisciplina($conexao){
	$professoresDisciplinas = array();
	$resultado = mysqli_query($conexao, "select pd.*, p.nome as professor_nome, d.nome as disciplina_nome, c.nome as curso_nome
										from professordisciplina as pd 
										join professores as p on pd.professor_id  = p.id
										join cursos as c on pd.curso_id  = c.id
										join disciplinas as d on pd.disciplina_id = d.id");
	while($professorDisciplina = mysqli_fetch_assoc($resultado)){
		array_push($professoresDisciplinas, $professorDisciplina);
	}
	return $professoresDisciplinas;
}

function removeProfessorDisciplina($conexao,$id){
	$query = "delete from professordisciplina where id={$id}";
	return mysqli_query($conexao,$query);
}

function buscaProfessorDisciplina($conexao, $id){
	$query = "select * from professordisciplina where id={$id}";
	$resultado = mysqli_query($conexao, $query);
	return mysqli_fetch_assoc($resultado);
}

function alteraProfessorDisciplina($conexao, $id, $semestre, $curso_id, $disciplina_id, $professor_id) {
	$query = "update professordisciplina set semestre = '{$semestre}', curso_id= {$curso_id}, disciplina_id = {$disciplina_id}, professor_id = {$professor_id}
	where id = '{$id}'";
	return mysqli_query($conexao, $query);
}
?>