<?php

	function insereProfessor($conexao, $nome, $email, $formacao_id){
		$nome = addslashes($nome);
		$query="insert into professores(nome, formacao_id, email) values('{$nome}','{$formacao_id}','{$email}')";
		$resultadoDaInsercao= mysqli_query($conexao, $query);
		return $resultadoDaInsercao;
	}
	function listaProfessores($conexao) {
		$professores = array();
		$resultado = mysqli_query($conexao, "select p.*, f.nome as formacao_nome
										from professores as p 
										join formacoes  as f on p.formacao_id  = f.id");
		while($professor = mysqli_fetch_assoc($resultado)) {
			array_push($professores, $professor);
		}
		return $professores;
	}
	function listaProfessores2($conexao) {
		$professores = array();
		$resultado = mysqli_query($conexao, "select * from professores order By nome ASC");
		while($professor = mysqli_fetch_assoc($resultado)) {
			array_push($professores, $professor);
		}
		return $professores;
	}
	function removeProfessor($conexao,$id){
		$query = "delete from professores where id={$id}";
		return mysqli_query($conexao,$query);
	}
	function buscaProfessor($conexao, $id){
		$query = "select * from professores where id={$id}";
		$resultado = mysqli_query($conexao, $query);
		return mysqli_fetch_assoc($resultado);
	}
	function alteraProfessor($conexao, $id, $nome,  $email, $formacao_id) {
		$query = "update professores set nome = '{$nome}', formacao_id= {$formacao_id}, email = '{$email}'
        where id = '{$id}'";
		return mysqli_query($conexao, $query);
	}
?>