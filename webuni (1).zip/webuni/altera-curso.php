<?php include("cabecalho.php");            
 include("banco-curso.php");
include("logica-usuario.php");
verificaUsuario();
$id = $_POST['id'];
$nome = $_POST['nome'];?>
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="indexadm.php">Home</a>
				<span>Cursos</span>
			</div>
		</div>
	</div>
<?php
if(alteraCurso($conexao, $id, $nome)) { ?>
    <p class="text-success">O curso <?= $nome ?> foi alterado.</p>
<?php } else {
    $msg = mysqli_error($conexao);
?>
    <p class="text-danger">O curso <?= $nome ?> não foi alterado: <?= $msg?></p>
<?php
}
?>

<?php include("rodape.php"); ?>