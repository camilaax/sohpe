<?php require_once("cabecalho.php");?>
<?php require_once("banco-sala.php");?>
<?php //include("logica-usuario.php");
//verificaUsuario();?>
<?php
	$id=$_POST['id'];
	removeDisciplina($conexao, $id);
header("Location: lista-disciplina.php?removido=true");
die();

	
	require_once("rodape.php");?>  