<?php 
require_once("cabecalho.php");

//require_once("logica-usuario.php");
//verificaUsuario();

?>
<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Salas</span>
			</div>
		</div>
	</div>

	<h1>Formulário de cadastro</h1>
	<form action="adiciona-sala.php" method="post">
		<table>
			<tr>
				<td>Numero: </td>
				<td><input class="form-control" type="number" name="numsala"/></td>
			</tr>
			<tr>
				<td>Bloco: </td>
				<td>
					<select name="bloco">
						<option value="A">A
						<option value="B">B
						<option value="C">C
						<option value="D">D
						<option value="E">E
						<option value="M">M
					</select>
				</td>
			</tr>
			<tr>
				<td>Tipo: </td>
				<td>
					<select name="tipo">
						<option value="Sala de aula">Sala de aula
						<option value="Laboratório de Informática">Laboratório de Informática
						<option value="Laboratório de Mecânica">Laboratório de Mecânica
						<option value="Laboratório de Biologia">Laboratório de Biologia
						<option value="Laboratório de Química">Laboratório de Química
					</select>
				</td>
			</tr>
			<tr>
				<td><input class="btn btn-primary" type="submit" value="Cadastrar"/></td><br>
			</tr>
		</table>
	</form>
<?php include("rodape.php");?>