<?php 
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-curso.php");
require_once("banco-professor.php");
require_once("banco-disciplina.php");
require_once("banco-professor-disciplina.php");
$cursos = listaCursos($conexao);
$professores = listaProfessores($conexao);
$disciplinas = listaDisciplinas($conexao);
$id = $_POST['id'];
 
$professorDisciplina = buscaProfessorDisciplina($conexao, $id);
?>
<?php
	if(array_key_exists("alterado",$_GET)&& ($_GET['alterado']=='true')){
?>
	<p class="alert-success">Professor/Disciplina alterado com sucesso.</p>
<?php } ?>
<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Professores/Disciplina</span>
			</div>
		</div>
	</div>
<!-- Page info end -->

<h1>Formulário de alteração</h1>
<form action="altera-professor-disciplina.php" method="post" >
	<input type="hidden" name="id" value="<?=$professorDisciplina['id']?>"/>
	<div class="row">
		<div class="col-sm-2">
				<fieldset>
					<legend>Semestre</legend>
					<select name="semestre" autofocus>
							<?php $esseSemestre = $professorDisciplina['semestre'] == "2019-2";
								$selecao = $esseSemestre ? "selected='selected'" : "";?>
							<option value="2019-2" <?=$selecao?>>2019-2
							<?php $esseSemestre = $professorDisciplina['semestre'] == "2020-1";
								$selecao = $esseSemestre ? "selected='selected'" : "";?>
							<option value="2020-1" <?=$selecao?>>2020-1
							<?php $esseSemestre = $professorDisciplina['semestre'] == "2020-2";
								$selecao = $esseSemestre ? "selected='selected'" : "";?>
							<option value="2020-2" <?=$selecao?>>2020-2
							<?php $esseSemestre = $professorDisciplina['semestre'] == "2021-1";
								$selecao = $esseSemestre ? "selected='selected'" : "";?>
							<option value="2021-1" <?=$selecao?>>2021-1
							<?php $esseSemestre = $professorDisciplina['semestre'] == "2021-2";
								$selecao = $esseSemestre ? "selected='selected'" : "";?>
							<option value="2021-2" <?=$selecao?>>2021-2
						</select>
				</fieldset>
		</div>
		<div class="col-sm-3">
				<fieldset>
					<legend>Curso</legend>
					<select name="curso_id" class="form-control">
							<?php foreach($cursos as $curso) : 
								$essaCurso = $curso['id'] == $professorDisciplina['curso_id'];
								$selecao = $essaCurso ? "selected='selected'" : "";
							?>
							<option value="<?=$curso['id']?>" <?=$selecao?>><?=$curso['nome']?>
							</option>
							<?php endforeach ?>
						</select>
				</fieldset>
		</div>
		<div class="col-sm-3">
				<fieldset>
					<legend>Professor</legend>
						<select name="professor_id" class="form-control">
							<?php foreach($professores as $professor) : 
								$esseProfessor= $professorDisciplina['professor_id'] == $professor['id'];
								$selecao = $esseProfessor ? "selected='selected'" : "";
							?>
							<option value="<?=$professor['id']?>" <?=$selecao?>><?=$professor['nome']?>
							</option>
							<?php endforeach ?>
						</select>
				</fieldset>
		</div>
		<div class="col-sm-3">
				<fieldset>
					<legend>Disciplina</legend>
					<select name="disciplina_id" class="form-control">
							<?php foreach($disciplinas as $disciplina) : 
								$essaDisciplina = $disciplina['id'] == $professorDisciplina['disciplina_id'];
								$selecao = $essaDisciplina ? "selected='selected'" : "";
							?>
							<option value="<?=$disciplina['id']?>" <?=$selecao?>><?=$disciplina['nome']?>
							</option>
							<?php endforeach ?>
						</select>
				</fieldset>
		</div>
		
		<div class="col-sm-1">
			<fieldset>
				<legend>Altera</legend>
				<td><input class="btn btn-dark" type="submit" name="alterar" value="Alterar" /> <td>
			</fieldset>
		</div>
	</div>
</form>	


<?php 
require_once("rodape.php");
?>