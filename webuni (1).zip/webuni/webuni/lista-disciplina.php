
<?php 
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-disciplina.php");
$disciplinas = listaDisciplinas($conexao);
?>
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Disciplina</span>
				<?php 
					  if(array_key_exists("removido", $_GET) && $_GET['removido']=='true') { 
					?>
					  
					 <p class="alert-success">Disciplina apagada com sucesso.</p>

					<?php
					  }
 ?>
			</div>
		</div>
	</div>
<table class="table table-striped table-bordered">
	<tr>
		<th><h4>Nome</h4></th>
		<th><h4>Alterar</h4></th>
		<th><h4>Remover</h4></th>
		
	
	<?php
	
		foreach($disciplinas as $disciplina){
			?>
			<tr>
				<td><?=$disciplina['nome']?></td>
				<td>
					<form action="disciplina-altera-formulario.php?id=<?=$disciplina['id']?>" method="post">
						<input type="hidden" name="id" value="<?=$disciplina['id']?>"/>
							<button class="btn btn-primary">Alterar</button>
					</form>
				</td>
				<td>
					<form action="remove-disciplina.php?id=<?=$disciplina['id']?>" method="post">
						<input type="hidden" name="id" value="<?=$disciplina['id']?>"/>
							<button class="btn btn-danger">Remover</button>
					</form>
				</td>
			</tr>
		<?php }?>
</table>
<?php include("rodape.php");?>