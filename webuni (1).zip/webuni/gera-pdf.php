<?php
	include("conecta.php");
	include("banco-professor.php");
	include("banco-curso.php");
	include("banco-disciplina.php");
	include("MPDF57/mpdf.php");
	$id = $_POST['id'];
	$professor = buscaProfessor($conexao, $id);
	$curso = buscaCurso($conexao, $id);
	$disciplina = buscaDisciplina($conexao, $id);
	$permanencia = buscaPermanencia($conexao, $id)
	$html="
		<h1>Sistema Gerenciador de Horarios de Permanencia</h1>
		<table>
			<tr>
				<td>
					<h3>Curso:</h3>
				</td>
				<td>
					<h4>".$curso['nome']."</h4>
				</td>
			</tr>
			<tr>
				<td>
					<h3>Disciplina:</h3>
				</td>
				<td>
					<h4>".$disciplina['nome']."</h4>
				</td>
			</tr>
			<tr>
				<td>
					<h3>Hora Inicio:</h3>
				</td>
				<td>
					<h4>".$permanencia['horainicio']."</h4>
				</td>
			</tr>
			<tr>
				<td>
					<h3>Hora Termino:</h3>
				</td>
				<td>
					<h4>".$permanencia['horatermino']."</h4>
				</td>
			</tr>
			<tr>
				<td>
					<h3>Semestre:</h3>
				</td>
				<td>
					<h4>".$permanencia['semestre']."</h4>
				</td>
			</tr>
			<tr>
				<td>
					<h3>Dia da semana:</h3>
				</td>
				<td>
					<h4>".$permanencia['diasemana']."</h4>
				</td>
			</tr>
			<tr>
				<td>
					<h3>Sala:</h3>
				</td>
				<td>
					<h4>".$sala['']."</h4>
				</td>
			</tr>
			<tr>
				<td>
					<h3>Nome do professor:</h3>
				</td>
				<td>
					<h4>".$professor['nome']."</h4>
				</td>
			</tr>
		</table>
	";
	$mpdf=new mPDF();
	$mpdf->SetDisplayMode('fullpage');
	$css=file_get_contents("estilo.css");
	$mpdf->WriteHTML($css,1);
	$mpdf->WriteHTML($html);
	$mpdf->Output();
?>
		