
	
	<?php 
include("cabecalho.php");
include("conecta.php");
include("banco-professor-disciplina.php");


$id = $_POST['id']; 
removeProfessorDisciplina($conexao, $id);

header("Location: professor-disciplina-lista.php?removido=true");
die();

include("rodape.php");
?>