<?php
include("cabecalho.php");
?>


	<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/4.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Contato</span>
			</div>
		</div>
	</div>
	
	<!-- Page -->
	<section class="contact-page spad pb-0">
		<div class="container">
			<div class="row">
				<div class="col-lg-8">
					<div class="contact-form-warp">
						<div class="section-title text-white text-left">
							<h2>Entrar em Contato</h2>
							<p>Essse espaço foi idealizado para o usurio entrar em contato conosco</p>
						</div>
						<form class="contact-form">
							<input type="text" placeholder="Nome Completo">
							<input type="text" placeholder="E-mail">
							<input type="text" placeholder="Subject">
							<textarea placeholder="Mensagem"></textarea>
							<button class="site-btn">Enviar</button>
						</form>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="contact-info-area">
						<div class="section-title text-left p-0">
							<h2>Informações para Contato</h2>
							<p> Sinta-se a vontade de mandar sujestoes de melhoria ou elogios, esse espaço é todo seu <i class="fa fa-heart-o" aria-hidden="true"></i></p>
						</div>
						<div class="social-links">
							<a href="#"><i class="fa fa-pinterest"></i></a>
							<a href="#"><i class="fa fa-facebook"></i></a>
							<a href="#"><i class="fa fa-twitter"></i></a>
							<a href="#"><i class="fa fa-dribbble"></i></a>
							<a href="#"><i class="fa fa-behance"></i></a>
							<a href="#"><i class="fa fa-linkedin"></i></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Page end -->
<?php
include("rodape.php");
?>
</html>