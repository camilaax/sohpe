<?php 
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-sala.php");
require_once("banco-professor.php");
require_once("banco-pe.php");
$professores = listaProfessores2($conexao);
$salas = listaSalas($conexao);
$id = $_POST['id'];
 
$permanencia = buscaPermanencia($conexao, $id);
?>
<?php
	if(array_key_exists("alterada",$_GET)&& ($_GET['alterada']=='true')){
?>
	<p class="alert-success">Permanência alterada com sucesso.</p>
<?php } ?>
<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Permanência</span>
			</div>
		</div>
	</div>
<!-- Page info end -->

<h1>Formulário de alteração</h1>
<form action="altera-pe.php" method="post" >
	<input type="hidden" name="id" value="<?=$id?>"/>
<table>
	<tr>
		<td>Horário de Início</td>
		<td><input class="form-control" type="time" name="horainicio" value="<?=$permanencia['horainicio']?>"/></td>
	</tr>
	<tr>
		<td>Horário de Término</td>
		<td><input class="form-control" type="time" name="horatermino" value="<?=$permanencia['horatermino']?>"/></td>
	</tr>
	<tr>
		<td> Semestre</td>
		<td>
			<select name="semestre" class="form-control">
				<?php $esseSemestre = $permanencia['semestre'] == "2019-2";
					$selecao = $esseSemestre ? "selected='selected'" : "";?>
				<option value="2019-2" <?=$selecao?>>2019-2
				<?php $esseSemestre = $permanencia['semestre'] == "2020-1";
					$selecao = $esseSemestre ? "selected='selected'" : "";?>
				<option value="2020-1" <?=$selecao?>>2020-1
				<?php $esseSemestre = $permanencia['semestre'] == "2020-2";
					$selecao = $esseSemestre ? "selected='selected'" : "";?>
				<option value="2020-2" <?=$selecao?>>2020-2
				<?php $esseSemestre = $permanencia['semestre'] == "2021-1";
					$selecao = $esseSemestre ? "selected='selected'" : "";?>
				<option value="2021-1" <?=$selecao?>>2021-1
				<?php $esseSemestre = $permanencia['semestre'] == "2021-2";
					$selecao = $esseSemestre ? "selected='selected'" : "";?>
				<option value="2021-2" <?=$selecao?>>2021-2
			</select>
		</td>
	</tr>
	<tr>
		<td>Dia da semana</td>
		<td>
			<select name="diasemana" class="form-control">
				<?php $esseDiaSemana = $permanencia['diasemana'] == "Segunda-feira";
					$selecao = $esseDiaSemana ? "selected='selected'" : "";?>
				<option value="Segunda-feira"" <?=$selecao?>>Segunda-feira
				<?php $esseDiaSemana = $permanencia['diasemana'] == "Terça-feira";
					$selecao = $esseDiaSemana ? "selected='selected'" : "";?>
				<option value="Terça-feira" <?=$selecao?>>Terça-feira
				<?php $esseDiaSemana = $permanencia['diasemana'] == "Quarta-feira";
					$selecao = $esseDiaSemana ? "selected='selected'" : "";?>
				<option value="Quarta-feira" <?=$selecao?>>Quarta-feira
				<?php $esseDiaSemana = $permanencia['diasemana'] == "Quinta-feira";
					$selecao = $esseDiaSemana ? "selected='selected'" : "";?>
				<option value="Quinta-feira" <?=$selecao?>>Quinta-feira
				<?php $esseDiaSemana = $permanencia['diasemana'] == "Sexta-feira";
					$selecao = $esseDiaSemana ? "selected='selected'" : "";?>
				<option value="Sexta-feira" <?=$selecao?>>Sexta-feira
				<?php $esseDiaSemana = $permanencia['diasemana'] == "Sábado";
					$selecao = $esseDiaSemana ? "selected='selected'" : "";?>
				<option value="Sábado" <?=$selecao?>>Sábado
			</select>
		</td>
	</tr>
	<tr>
	<td>Sala</td>
		<td>
			<select name="sala_id" class="form-control">
					<?php foreach($salas as $sala) : 
						$essaSala = $sala['id'] == $permanencia['sala_id'];
						$selecao = $essaSala ? "selected='selected'" : "";
					?>
					<option value="<?=$sala['id']?>" <?=$selecao?>><?=$sala['bloco']?><?=$sala['numsala']?>
					</option>
					<?php endforeach ?>
			</select>
		</td>
	</tr>
		<tr>
		<td>Professor</td>
		<td>
			<select name="professor_id" class="form-control">
					<?php foreach($professores as $professor) : 
						$esseProfessor = $professor['id'] == $permanencia['professor_id'];
						$selecao = $esseProfessor ? "selected='selected'" : "";
					?>
					<option value="<?=$professor['id']?>" <?=$selecao?>><?=$professor['nome']?>
					</option>
					<?php endforeach ?>
			</select>
		</td>
	</tr>
	<tr>
		<td><input class="btn btn-dark" type="submit" name="alterar" value="Alterar" /> <td>
	</tr>
</table>
</form>	

<?php 
require_once("rodape.php");
?>