<script src="js/funcoes.js"></script>

<script>
 // Mudarestado('escondidol');
 //deixarOculto('escondidol');
</script>

<?php
require_once("cabecalho.php");
require_once("conecta.php");
require_once("banco-professor.php");
require_once("banco-sala.php");
require_once("banco-disciplina.php");
$professores = listaProfessores2($conexao);
$salas = listaSalas($conexao);
$disciplinas = listaDisciplinas($conexao);
?>

	<!-- Hero section -->
	<section class="hero-section set-bg" data-setbg="img/bg.jpg">
		<div class="container">
			<div class="hero-text text-white">
				<h1>Consulta PE</h1>
				<form action="" method="post" name="pesquisa">
					<input  class="radio1" type="radio" name="filtro" checked value="1" onclick="Mudarestado1('escondido1','escondido2','escondido3')"> Por professor
					<input class="radio1" type="radio" name="filtro" value="2" onclick="Mudarestado2('escondido1','escondido2','escondido3')"> Por Disciplina
					<input class="radio1" type="radio" name="filtro" value="3" onclick="Mudarestado3('escondido1','escondido2','escondido3')"> Por Sala
					<!--<button class="site-btn" type="button" onclick="Mudarestado('escondido1')">Procurar</button>-->
				</form>
			</div>
				<div class="row">
					<div class="col-lg-10 offset-lg-1">
						<div id="escondido1">
							<form  class="intro-newslatter" action="consulta-permanencia.php" method="post">
								<input type="hidden" name="filtro" value="1"/>
								<select name="professor_id" class="form-control">
									<?php foreach($professores as $professor) : ?>
									<option value="<?=$professor['id']?>"><?=$professor['nome']?></option>
									<?php endforeach ?>
								</select>
								<button class="site-btn">Consultar PE</button>
							</form>
						</div>
						<div id="escondido2">
							<form  class="intro-newslatter" action="consulta-permanencia.php" method="post">
								<input type="hidden" name="filtro" value="2"/>
								<select name="disciplina_id" class="form-control">
									<?php foreach($disciplinas as $disciplina) : ?>
									<option value="<?=$disciplina['id']?>"><?=$disciplina['nome']?></option>
									<?php endforeach ?>
								</select>
								<button class="site-btn">Consultar PE</button>
							</form>
						</div>
						<div id="escondido3">
							<form  class="intro-newslatter" action="consulta-permanencia.php" method="post">
								<input type="hidden" name="filtro" value="3"/>
								<select name="sala_id" class="form-control">
									<?php foreach($salas as $sala) : ?>
									<option value="<?=$sala['id']?>"><?=$sala['bloco']?><?=$sala['numsala']?></option>
									<?php endforeach ?>
								</select>
								<button class="site-btn">Consultar PE</button>
							</form>
						</div>
					</div>
				</div>
						
		</div>
	</section>

<?php
include("rodape.php");
?>