
	
	<?php 
include("cabecalho.php");
include("conecta.php");
include("banco-professor.php");


$id = $_POST['id']; 
removeProfessor($conexao, $id);

header("Location: professor-lista.php?removido=true");
die();

include("rodape.php");
?>