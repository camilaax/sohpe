	
	
<?php 
  require_once("cabecalho.php"); 
  require_once("conecta.php"); 
  require_once("banco-curso.php");
  $id = $_POST['id'];
  $curso = buscaCurso($conexao, $id);
?>
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="indexadm.php">Home</a>
				<span>Cursos</span>
			</div>
		</div>
	</div>
	
	<h1>Altera Curso</h1>
	<form action="altera-curso.php" method="post">
		<table class="table">
			<input type="hidden" name="id" value="<?=$curso['id']?>"/>
				<tr>
					<td>Nome: </td>
					<td><input class="form-control" type="text" name="nome" value="<?=$curso['nome']?>"/></td><br>
				</tr>
								<tr>
					<td><input class="btn btn-primary" type="submit" value="Alterar"/></td><br>
				</tr>
		</table>
	</form>


<?php include("rodape.php"); ?>