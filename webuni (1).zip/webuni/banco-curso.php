<?php	

function listaCursos($conexao){
	$cursos = array();
	$query = "select * from cursos";
	$resultado = mysqli_query($conexao, $query);
	while($curso = mysqli_fetch_assoc($resultado)){
		array_push($cursos, $curso);
	}
	return $cursos;
}
function insereCursos($conexao, $nome){
	$query="insert into cursos(nome) values('{$nome}')";
	$resultadoDaInsercao= mysqli_query($conexao, $query);
	return $resultadoDaInsercao;
}
function buscaCurso($conexao, $id){
	$query = "select * from cursos where id={$id}";
	$resultado = mysqli_query($conexao, $query);
	return mysqli_fetch_assoc($resultado);
}
function removeCurso($conexao,$id){
	$query = "delete from cursos where id={$id}";
	return mysqli_query($conexao,$query);
}
function alteraCurso($conexao,$id, $nome) {
	$query = "update cursos set nome = '{$nome}'
				where id = '{$id}'";
	return mysqli_query($conexao, $query);
}