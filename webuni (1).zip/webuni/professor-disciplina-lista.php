<?php 
require_once("cabecalho.php");
require_once("conecta.php");
include("banco-professor-disciplina.php");
$professoresDisciplinas = listaProfessorDisciplina($conexao);
?>
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Professor/Disciplina</span>
				<?php 
					  if(array_key_exists("removido", $_GET) && $_GET['removido']=='true') { 
					?>
					  
					 <p class="alert-success">Professor/disciplina apagado com sucesso.</p>

					<?php
					  }
 ?>
			</div>
		</div>
	</div>

<!-- Page info -->



<!-- Page info end -->
<table class="table table-striped table-bordered">
	<tr>
		<th><h4>Semestre</h4></th>
		<th><h4>Curso</h4></th>
		<th><h4>Disciplina</h4></th>
		<th><h4>Professor</h4></th>
		<th><h4>Alterar</h4></th>
		<th><h4>Remover</h4></th>
		
	
	<?php
	
		foreach($professoresDisciplinas as $professorDisciplina){
			?>
			<tr>
				
				<td><?=$professorDisciplina['semestre']?></td>
				<td><?=$professorDisciplina['curso_nome']?></td>
				<td><?=$professorDisciplina['professor_nome']?></td>
				<td><?=$professorDisciplina['disciplina_nome']?></td>
				
				<td>
					<form action="professor-disciplina-altera-formulario.php?id=<?=$professorDisciplina['id']?>" method="post">
						<input type="hidden" name="id" value="<?=$professorDisciplina['id']?>"/>
							<button class="btn btn-primary">Alterar</button>
					</form>
				</td>
				<td>
					<form action="remove-professor-disciplina.php?id=<?=$professorDisciplina['id']?>" method="post">
						<input type="hidden" name="id" value="<?=$professorDisciplina['id']?>"/>
							<button class="btn btn-danger">Remover</button>
					</form>
				</td>
			</tr>
		<?php }?>
</table>
<?php include("rodape.php");?>