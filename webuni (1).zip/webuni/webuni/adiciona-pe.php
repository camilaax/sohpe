<?php include("cabecalho.php");?>
<?php include("conecta.php");?>
<?php include("banco-pe.php");?>
<?phpinclude("logica-usuario.php");
verificaUsuario();?>
<!-- Page info -->
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Permanência</span>
			</div>
		</div>
	</div>
<!-- Page info end -->
	<?php
	$horainicio=$_POST["horainicio"];
	$horatermino=$_POST["horatermino"];
	$semestre=$_POST["semestre"];
	$diasemana=$_POST["diasemana"];
	$sala_id=$_POST["sala_id"];
	$professor_id=$_POST["professor_id"];
	?>

	<?php
		
		$resultado = inserePermanencias($conexao, $horainicio,$horatermino, $semestre, $diasemana, $sala_id, $professor_id);
		if($resultado){?>
			<p class="alert-success">
				Permanência adicionada com sucesso!<br>
			</p>
		<?php 
		}else{
			?>
			<p class "alert-danger"> Permanência adicionada não foi adicionado!<br>
			</p>
		<?php
		}
		mysqli_close($conexao);?>
<?php include("rodape.php");?>
