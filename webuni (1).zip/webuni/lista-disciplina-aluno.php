<?php 
require_once("cabecalhoaluno.php");
require_once("conecta.php");
require_once("banco-disciplina.php");
$disciplinas = listaDisciplinas($conexao);
?>
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Disciplina</span>
			</div>
		</div>
	</div>
<table class="table table-striped table-bordered">
	<tr>
		<th><h4>Nome</h4></th>
		
	
	<?php
	
		foreach($disciplinas as $disciplina){
			?>
			<tr>
				<td><?=$disciplina['nome']?></td>
			</tr>
		<?php }?>
</table>
<?php include("rodape.php");?>