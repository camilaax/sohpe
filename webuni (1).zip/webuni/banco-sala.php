<?php	

function listaSalas($conexao){
	$salas = array();
	$query = "select * from salas";
	$resultado = mysqli_query($conexao, $query);
	while($sala = mysqli_fetch_assoc($resultado)){
		array_push($salas, $sala);
	}
	return $salas;
}
function insereSala($conexao, $numsala, $bloco, $tipo){
	$query="insert into salas(numsala, bloco, tipo) values('{$numsala}','{$bloco}','{$tipo}')";
	$resultadoDaInsercao= mysqli_query($conexao, $query);
	return $resultadoDaInsercao;
}
function buscaSala($conexao, $id){
	$query = "select * from salas where id={$id}";
	$resultado = mysqli_query($conexao, $query);
	return mysqli_fetch_assoc($resultado);
}
function removeSala($conexao,$id){
	$query = "delete from salas where id={$id}";
	return mysqli_query($conexao,$query);
}
function alteraSala($conexao,$id,$numsala,$bloco,$tipo ) {
	$query = "update salas set numsala = {$numsala}, bloco='{$bloco}', tipo='{$tipo}'
				where id = '{$id}'";
	return mysqli_query($conexao, $query);
}?>