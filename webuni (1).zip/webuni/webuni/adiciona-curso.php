<?php include("cabecalho.php");?>
<?php include("banco-curso.php");?>
<?php include("conecta.php");?>
<?php include("logica-usuario.php");
verificaUsuario();?>
	<div class="page-info-section set-bg" data-setbg="img/page-bg/3.jpg">
		<div class="container">
			<div class="site-breadcrumb">
				<a href="index.php">Home</a>
				<span>Professores</span>
			</div>
		</div>
	</div>
	<?php
	$nome=$_POST["nome"];
	?>
	<br><br><br><br>
	<?php
		
		$resultado = insereCursos($conexao, $nome);
		if($resultado){?>
			<p class="alert-success">
				Curso Nome=<?=$nome?> adicionado com sucesso!<br>
			</p>
		<?php 
		}else{
			?>
			<p class "alert-danger">O curso <?=$nome;?> não foi adicionado!<br>
			</p>
		<?php
		}
		mysqli_close($conexao);?>
<?php include("rodape.php");?>

